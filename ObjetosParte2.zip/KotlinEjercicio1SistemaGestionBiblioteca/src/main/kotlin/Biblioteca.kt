class Biblioteca {
    private val libros = mutableListOf<Libro>()
    private val prestamos = mutableMapOf<Usuario, Libro>()

    fun agregarLibro(libro: Libro) {
        libros.add(libro)
    }

    fun registrarUsuario(usuario: Usuario) {
        println("Usuario registrado: ${usuario.nombre}")
    }

    fun prestarLibro(libro: Libro, usuario: Usuario): Boolean {
        return if (libro.prestado) {
            println("El libro ya está prestado.")
            false
        } else {
            libro.prestado = true
            prestamos[usuario] = libro
            println("Libro prestado a ${usuario.nombre}")
            true
        }
    }
}