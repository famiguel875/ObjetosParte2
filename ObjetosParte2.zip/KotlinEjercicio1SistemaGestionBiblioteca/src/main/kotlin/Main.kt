fun main() {
    val biblioteca = Biblioteca()
    val libro1 = Libro("El Principito")
    val libro2 = Libro("1984")
    val usuario1 = Usuario("Juan")

    biblioteca.agregarLibro(libro1)
    biblioteca.agregarLibro(libro2)
    biblioteca.registrarUsuario(usuario1)

    biblioteca.prestarLibro(libro1, usuario1)
    biblioteca.prestarLibro(libro1, usuario1)
}