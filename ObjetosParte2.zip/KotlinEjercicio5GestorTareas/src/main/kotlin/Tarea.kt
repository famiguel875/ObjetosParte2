class Tarea(val nombre: String, var completada: Boolean = false) {
    fun marcarCompletada() {
        completada = true
    }
}