fun main() {
    val proyecto = Proyecto("Proyecto Kotlin")
    val tarea1 = Tarea("Diseñar UI")
    val tarea2 = Tarea("Implementar backend")

    proyecto.agregarTarea(tarea1)
    proyecto.agregarTarea(tarea2)

    tarea1.marcarCompletada()

    println("Tareas del proyecto ${proyecto.nombre}:")
    proyecto.tareas.forEach { tarea ->
        println("- ${tarea.nombre} (Completada: ${tarea.completada})")
    }
}