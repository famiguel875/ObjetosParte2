fun main() {
    val hotel = Hotel()
    val habitacion1 = Habitacion(101)
    val cliente1 = Cliente("Ana")

    hotel.reservar(habitacion1, cliente1)
    hotel.mostrarReservasActivas()

    hotel.cancelarReserva(cliente1)
}