class Hotel {
    private val reservas = mutableListOf<Reserva>()

    fun reservar(habitacion: Habitacion, cliente: Cliente) {
        reservas.add(Reserva(cliente, habitacion))
        println("Habitación ${habitacion.numero} reservada a ${cliente.nombre}")
    }

    fun cancelarReserva(cliente: Cliente) {
        reservas.removeAll { it.cliente == cliente }
        println("Reserva cancelada para ${cliente.nombre}")
    }

    fun mostrarReservasActivas() {
        reservas.forEach { reserva ->
            println("Reserva: Cliente ${reserva.cliente.nombre}, Habitación ${reserva.habitacion.numero}")
        }
    }
}