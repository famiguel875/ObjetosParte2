class Curso {
    String nombre;

    Curso(String nombre) {
        this.nombre = nombre;
    }
}