import java.util.ArrayList;
import java.util.List;

class Estudiante {
    String nombre;
    List<Integer> calificaciones;

    Estudiante(String nombre) {
        this.nombre = nombre;
        this.calificaciones = new ArrayList<>();
    }

    void agregarCalificacion(int calificacion) {
        calificaciones.add(calificacion);
    }

    // Retorna el promedio como una cadena formateada con 2 decimales
    String calcularPromedio() {
        if (calificaciones.isEmpty()) return "0.00";
        double suma = 0;
        for (int calificacion : calificaciones) {
            suma += calificacion;
        }
        double promedio = suma / calificaciones.size();
        return String.format("%.2f", promedio); // Devuelve el promedio formateado como cadena
    }
}