class Profesor {
    String nombre;

    Profesor(String nombre) {
        this.nombre = nombre;
    }

    void asignarCurso(Estudiante estudiante, Curso curso) {
        System.out.println("Curso " + curso.nombre + " asignado a " + estudiante.nombre);
    }
}