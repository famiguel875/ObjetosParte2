class Mago(nombre: String) : Personaje(nombre, 80) {
    fun usarHechizo(enemigo: Personaje) {
        val danio = 20
        enemigo.vida -= danio
        println("$nombre (Mago) usa un hechizo en ${enemigo.nombre} y le quita $danio puntos de vida.")
        verificarVida(enemigo)
    }
}