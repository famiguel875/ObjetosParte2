open class Personaje(val nombre: String, var vida: Int) {
    open fun atacar(enemigo: Personaje) {
        val danio = 10
        enemigo.vida -= danio
        println("$nombre ataca a ${enemigo.nombre} y le quita $danio puntos de vida.")
        verificarVida(enemigo)
    }

    fun verificarVida(enemigo: Personaje) {
        if (enemigo.vida <= 0) {
            enemigo.vida = 0
            println("${enemigo.nombre} ha sido derrotado.")
        } else {
            println("Vida de ${enemigo.nombre}: ${enemigo.vida}")
        }
    }
}