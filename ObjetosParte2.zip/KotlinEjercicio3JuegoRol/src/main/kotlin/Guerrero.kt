class Guerrero(nombre: String) : Personaje(nombre, 100) {
    override fun atacar(enemigo: Personaje) {
        val danio = 15
        enemigo.vida -= danio
        println("$nombre (Guerrero) ataca a ${enemigo.nombre} y le quita $danio puntos de vida.")
        verificarVida(enemigo)
    }
}