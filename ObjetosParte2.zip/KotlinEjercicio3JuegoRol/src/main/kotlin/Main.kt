fun main() {
    val guerrero = Guerrero("Sauron")
    val mago = Mago("Gandalf")

    guerrero.atacar(mago)
    mago.usarHechizo(guerrero)
    guerrero.atacar(mago)
}