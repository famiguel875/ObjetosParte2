public class Main {
    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Proyecto Java");
        Tarea tarea1 = new Tarea("Diseñar UI");
        Tarea tarea2 = new Tarea("Implementar backend");

        proyecto.agregarTarea(tarea1);
        proyecto.agregarTarea(tarea2);

        tarea1.marcarCompletada();

        System.out.println("Tareas del proyecto " + proyecto.nombre + ":");
        for (Tarea tarea : proyecto.tareas) {
            System.out.println("- " + tarea.nombre + " (Completada: " + tarea.completada + ")");
        }
    }
}