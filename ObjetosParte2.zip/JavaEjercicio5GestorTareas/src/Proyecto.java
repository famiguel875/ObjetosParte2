import java.util.ArrayList;
class Proyecto {
    String nombre;
    ArrayList<Tarea> tareas = new ArrayList<>();

    Proyecto(String nombre) {
        this.nombre = nombre;
    }

    void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }
}