class Tarea {
    String nombre;
    boolean completada = false;

    Tarea(String nombre) {
        this.nombre = nombre;
    }

    void marcarCompletada() {
        completada = true;
    }
}