fun main() {
    val estudiante1 = Estudiante("Carlos")
    val estudiante2 = Estudiante("Ana")
    val estudiante3 = Estudiante("Luis")

    val curso = Curso("Matemáticas")
    val profesor = Profesor("Sr. López")

    profesor.asignarCurso(estudiante1, curso)
    profesor.asignarCurso(estudiante2, curso)
    profesor.asignarCurso(estudiante3, curso)

    estudiante1.agregarCalificacion(80)
    estudiante1.agregarCalificacion(90)
    estudiante1.agregarCalificacion(100)

    estudiante2.agregarCalificacion(70)
    estudiante2.agregarCalificacion(85)
    estudiante2.agregarCalificacion(90)

    estudiante3.agregarCalificacion(60)
    estudiante3.agregarCalificacion(75)
    estudiante3.agregarCalificacion(80)

    println("Promedio de ${estudiante1.nombre}: ${estudiante1.calcularPromedio()}")
    println("Promedio de ${estudiante2.nombre}: ${estudiante2.calcularPromedio()}")
    println("Promedio de ${estudiante3.nombre}: ${estudiante3.calcularPromedio()}")
}
