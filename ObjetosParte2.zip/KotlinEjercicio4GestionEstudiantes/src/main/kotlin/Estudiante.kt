class Estudiante(val nombre: String) {
    private val calificaciones = mutableListOf<Int>()

    fun agregarCalificacion(calificacion: Int) {
        calificaciones.add(calificacion)
    }

    fun calcularPromedio(): String {
        if (calificaciones.isEmpty()) return "0.00"
        val suma = calificaciones.sum()
        val promedio = suma.toDouble() / calificaciones.size
        return String.format("%.2f", promedio)
    }
}