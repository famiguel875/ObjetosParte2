class Profesor(val nombre: String) {
    fun asignarCurso(estudiante: Estudiante, curso: Curso) {
        println("Curso ${curso.nombre} asignado a ${estudiante.nombre}")
    }
}