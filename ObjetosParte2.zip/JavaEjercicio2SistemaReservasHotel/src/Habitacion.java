class Habitacion {
    int numero;

    Habitacion(int numero) {
        this.numero = numero;
    }
}