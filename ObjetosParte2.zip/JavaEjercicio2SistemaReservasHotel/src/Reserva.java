class Reserva {
    Cliente cliente;
    Habitacion habitacion;

    Reserva(Cliente cliente, Habitacion habitacion) {
        this.cliente = cliente;
        this.habitacion = habitacion;
    }
}