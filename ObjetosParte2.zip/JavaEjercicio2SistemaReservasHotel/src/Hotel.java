import java.util.ArrayList;

class Hotel {
    ArrayList<Reserva> reservas = new ArrayList<>();

    void reservar(Habitacion habitacion, Cliente cliente) {
        reservas.add(new Reserva(cliente, habitacion));
        System.out.println("Habitación " + habitacion.numero + " reservada a " + cliente.nombre);
    }

    void cancelarReserva(Cliente cliente) {
        reservas.removeIf(reserva -> reserva.cliente.equals(cliente));
        System.out.println("Reserva cancelada para " + cliente.nombre);
    }

    void mostrarReservasActivas() {
        for (Reserva reserva : reservas) {
            System.out.println("Reserva: Cliente " + reserva.cliente.nombre + ", Habitación " + reserva.habitacion.numero);
        }
    }
}