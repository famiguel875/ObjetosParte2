class Cliente {
    String nombre;

    Cliente(String nombre) {
        this.nombre = nombre;
    }
}