public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Habitacion habitacion1 = new Habitacion(101);
        Cliente cliente1 = new Cliente("Ana");

        hotel.reservar(habitacion1, cliente1);
        hotel.mostrarReservasActivas();

        hotel.cancelarReserva(cliente1);
    }
}
