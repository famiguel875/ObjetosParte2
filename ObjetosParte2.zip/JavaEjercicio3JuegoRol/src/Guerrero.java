class Guerrero extends Personaje {
    Guerrero(String nombre) {
        super(nombre, 100);
    }

    @Override
    void atacar(Personaje enemigo) {
        int danio = 15;
        enemigo.vida -= danio;
        System.out.println(nombre + " (Guerrero) ataca a " + enemigo.nombre + " y le quita " + danio + " puntos de vida.");
        verificarVida(enemigo);
    }
}