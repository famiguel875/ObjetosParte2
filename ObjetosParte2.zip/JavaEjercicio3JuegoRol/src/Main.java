public class Main {
    public static void main(String[] args) {
        Guerrero guerrero = new Guerrero("Sauron");
        Mago mago = new Mago("Gandalf");

        guerrero.atacar(mago);
        mago.usarHechizo(guerrero);
        guerrero.atacar(mago);
    }
}