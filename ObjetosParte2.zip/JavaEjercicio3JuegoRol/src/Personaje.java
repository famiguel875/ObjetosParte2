class Personaje {
    String nombre;
    int vida;

    Personaje(String nombre, int vida) {
        this.nombre = nombre;
        this.vida = vida;
    }

    void atacar(Personaje enemigo) {
        int danio = 10;
        enemigo.vida -= danio;
        System.out.println(nombre + " ataca a " + enemigo.nombre + " y le quita " + danio + " puntos de vida.");
        verificarVida(enemigo);
    }

    void verificarVida(Personaje enemigo) {
        if (enemigo.vida <= 0) {
            enemigo.vida = 0;
            System.out.println(enemigo.nombre + " ha sido derrotado.");
        } else {
            System.out.println("Vida de " + enemigo.nombre + ": " + enemigo.vida);
        }
    }
}