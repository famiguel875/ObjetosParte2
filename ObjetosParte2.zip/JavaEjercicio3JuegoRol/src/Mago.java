class Mago extends Personaje {
    Mago(String nombre) {
        super(nombre, 80);
    }

    void usarHechizo(Personaje enemigo) {
        int danio = 20;
        enemigo.vida -= danio;
        System.out.println(nombre + " (Mago) usa un hechizo en " + enemigo.nombre + " y le quita " + danio + " puntos de vida.");
        verificarVida(enemigo);
    }
}