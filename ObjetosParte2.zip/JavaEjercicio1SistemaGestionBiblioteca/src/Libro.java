class Libro {
    String titulo;
    boolean prestado = false;

    Libro(String titulo) {
        this.titulo = titulo;
    }
}