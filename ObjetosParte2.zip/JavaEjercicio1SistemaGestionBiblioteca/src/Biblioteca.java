import java.util.ArrayList;
import java.util.HashMap;

class Biblioteca {
    ArrayList<Libro> libros = new ArrayList<>();
    HashMap<Usuario, Libro> prestamos = new HashMap<>();

    void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    void registrarUsuario(Usuario usuario) {
        System.out.println("Usuario registrado: " + usuario.nombre);
    }

    boolean prestarLibro(Libro libro, Usuario usuario) {
        if (libro.prestado) {
            System.out.println("El libro ya está prestado.");
            return false;
        } else {
            libro.prestado = true;
            prestamos.put(usuario, libro);
            System.out.println("Libro prestado a " + usuario.nombre);
            return true;
        }
    }
}