public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Libro libro1 = new Libro("El Principito");
        Libro libro2 = new Libro("1984");
        Usuario usuario1 = new Usuario("Juan");

        biblioteca.agregarLibro(libro1);
        biblioteca.agregarLibro(libro2);
        biblioteca.registrarUsuario(usuario1);

        biblioteca.prestarLibro(libro1, usuario1);
        biblioteca.prestarLibro(libro1, usuario1);
    }
}