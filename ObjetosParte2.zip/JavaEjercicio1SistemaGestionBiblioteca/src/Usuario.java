class Usuario {
    String nombre;

    Usuario(String nombre) {
        this.nombre = nombre;
    }
}